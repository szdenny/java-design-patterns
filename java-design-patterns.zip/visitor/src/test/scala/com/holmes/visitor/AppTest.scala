package com.holmes.visitor

import org.junit.Test

/**
  * Created by denny.lao on 2017/2/23.
  */
class AppTest {
  @Test def test: Unit = {
    App.main(Array[String]())
  }
}

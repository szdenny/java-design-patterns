package com.holmes.delegation.simple

/**
  * Created by denny.lao on 2017/2/15.
  */
trait Printer {
  def print(message : String)
}

package com.holmes.delegation.simple

import org.junit.Test

/**
  * Created by denny.lao on 2017/2/15.
  */
class AppTest {
  @Test def test: Unit = {
    val args = new Array[String](0)
    App.main(args)
  }
}

package com.holmes.decorator

import org.junit.Test

/**
  * Created by denny.lao on 2017/2/13.
  */
class AppTest {
  @Test def test(): Unit = {
    val args: Array[String] = new Array[String](0)
    App.main(args)
  }
}
